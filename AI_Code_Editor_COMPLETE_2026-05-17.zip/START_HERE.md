# AI Code Editor - Start Here

This project is ready for browser-based free coding agent use.

## Instant no-install mode

If Node/npm is not installed yet, open this file directly in your browser:

```txt
FREE_LOCAL_EDITOR.html
```

It includes a simple free local coding agent for:

```txt
landing page
todo app
calculator
active-file improvement notes
```

## 1. Install Node.js

If `npm` is not recognized, install Node.js LTS from:

```txt
https://nodejs.org
```

After install, close and reopen PowerShell, then check:

```bash
node --version
npm --version
```

## 2. Install dependencies

```bash
npm install
```

## 3. Start the app

```bash
npm run dev
```

Open:

```txt
http://localhost:3000
```

## 4. Free coding mode

Open the Agent panel and choose:

```txt
Free local
```

Try prompts:

```txt
create a modern landing page
create a todo app
create a calculator
improve the active file layout
```

The agent will show:

```txt
Plan -> Validation -> Confidence -> Diff Preview -> Apply
```

## 5. Optional GPT mode

Create `.env.local`:

```txt
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4o-mini
AGENT_PROVIDER=auto
```

Without `OPENAI_API_KEY`, the Coding Agent still works in free local mode.
