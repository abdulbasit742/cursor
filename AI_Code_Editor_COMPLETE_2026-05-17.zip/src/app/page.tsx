"use client";

import {
  Bot,
  Download,
  Eye,
  PanelLeft,
  RotateCcw,
  Sparkles,
  Terminal
} from "lucide-react";
import AgentPanel from "@/components/Agent/AgentPanel";
import AiChat from "@/components/Chat/AiChat";
import CodeEditor from "@/components/Editor/CodeEditor";
import LivePreview from "@/components/Preview/LivePreview";
import FileExplorer from "@/components/Sidebar/FileExplorer";
import TerminalPanel from "@/components/Terminal/TerminalPanel";
import CommandPalette from "@/components/CommandPalette";
import SaveShortcut from "@/components/SaveShortcut";
import useStore from "@/store/useStore";
import { downloadProject } from "@/utils/downloadProject";

export default function HomePage() {
  const files = useStore((state) => state.files);
  const isSidebarOpen = useStore((state) => state.isSidebarOpen);
  const isChatOpen = useStore((state) => state.isChatOpen);
  const isAgentOpen = useStore((state) => state.isAgentOpen);
  const isTerminalOpen = useStore((state) => state.isTerminalOpen);
  const isPreviewOpen = useStore((state) => state.isPreviewOpen);
  const toggleSidebar = useStore((state) => state.toggleSidebar);
  const toggleChat = useStore((state) => state.toggleChat);
  const toggleAgent = useStore((state) => state.toggleAgent);
  const toggleTerminal = useStore((state) => state.toggleTerminal);
  const togglePreview = useStore((state) => state.togglePreview);
  const resetProject = useStore((state) => state.resetProject);

  return (
    <main className="h-screen w-screen app-bg flex flex-col overflow-hidden">
      <header className="h-11 panel-bg-2 border-b app-border flex items-center justify-between px-3 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button
            data-testid="toggle-sidebar-button"
            onClick={toggleSidebar}
            className="p-1.5 app-hover rounded"
            title="Toggle Sidebar"
          >
            <PanelLeft size={18} />
          </button>

          <h1 className="text-sm font-semibold truncate">AI Code Editor</h1>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => downloadProject(files)}
            className="flex items-center gap-1 px-3 py-1.5 rounded text-sm app-hover"
            title="Download project"
          >
            <Download size={16} />
            Download
          </button>

          <button
            onClick={resetProject}
            className="flex items-center gap-1 px-3 py-1.5 rounded text-sm app-hover"
            title="Reset project"
          >
            <RotateCcw size={16} />
            Reset
          </button>

          <button
            onClick={toggleAgent}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-sm ${
              isAgentOpen ? "bg-cyan-600 text-white" : "app-hover"
            }`}
            title="Toggle Coding Agent"
          >
            <Sparkles size={16} />
            Agent
          </button>

          <button
            data-testid="toggle-preview-button"
            onClick={togglePreview}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-sm ${
              isPreviewOpen ? "bg-[#007acc] text-white" : "app-hover"
            }`}
            title="Toggle Preview"
          >
            <Eye size={16} />
            Preview
          </button>

          <button
            data-testid="toggle-terminal-button"
            onClick={toggleTerminal}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-sm ${
              isTerminalOpen ? "bg-[#007acc] text-white" : "app-hover"
            }`}
            title="Toggle Terminal"
          >
            <Terminal size={16} />
            Terminal
          </button>

          <button
            data-testid="toggle-chat-button"
            onClick={toggleChat}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-sm ${
              isChatOpen ? "bg-[#007acc] text-white" : "app-hover"
            }`}
            title="Toggle AI Chat"
          >
            <Bot size={16} />
            AI Chat
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden min-h-0">
        {isSidebarOpen && <FileExplorer />}

        <section className="flex flex-col flex-1 min-w-0">
          <div className="flex flex-1 min-h-0">
            <div className={isPreviewOpen ? "w-1/2 h-full" : "w-full h-full"}>
              <CodeEditor />
            </div>

            {isPreviewOpen && (
              <div className="w-1/2 h-full">
                <LivePreview />
              </div>
            )}
          </div>

          {isTerminalOpen && <TerminalPanel />}
        </section>

        {isChatOpen && <AiChat />}
        {isAgentOpen && <AgentPanel />}
      </div>

      <footer className="h-6 bg-[#007acc] text-white text-xs flex items-center justify-between px-3 shrink-0">
        <span>Ready</span>
        <span>Built by Abdul Basit</span>
      </footer>

      <SaveShortcut />
      <CommandPalette />
    </main>
  );
}
