"use client";

const QUICK_PROMPTS = [
  "create a modern landing page",
  "create a todo app",
  "create a calculator",
  "improve the active file layout"
];

export default function AgentQuickPrompts({
  onSelect
}: {
  onSelect: (prompt: string) => void;
}) {
  return (
    <div className="rounded-lg border app-border app-bg p-3">
      <div className="text-xs font-semibold">Quick free builds</div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        {QUICK_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            onClick={() => onSelect(prompt)}
            className="rounded app-hover border app-border px-2 py-2 text-left text-xs"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}
