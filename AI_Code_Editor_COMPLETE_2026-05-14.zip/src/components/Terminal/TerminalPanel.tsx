"use client";

import { Terminal } from "lucide-react";
import { useState } from "react";

export default function TerminalPanel() {
  const [history, setHistory] = useState<string[]>([
    "AI Code Editor Terminal",
    "Type help to see available commands."
  ]);
  const [command, setCommand] = useState("");

  const runCommand = (cmd: string) => {
    const cleanCmd = cmd.trim();
    if (!cleanCmd) return;

    if (cleanCmd === "clear") {
      setHistory([]);
      return;
    }

    const outputMap: Record<string, string> = {
      help: "Available commands: help, clear, npm run dev, ls, pwd",
      "npm run dev": "Starting development server... Ready on http://localhost:3000",
      ls: "src  package.json  README.md",
      pwd: "/ai-code-editor"
    };

    setHistory((current) => [
      ...current,
      `$ ${cleanCmd}`,
      outputMap[cleanCmd] || `Command not found: ${cleanCmd}`
    ]);
  };

  return (
    <div className="h-48 app-bg border-t app-border flex flex-col shrink-0">
      <div className="h-9 panel-bg border-b app-border flex items-center gap-2 px-3 shrink-0">
        <Terminal size={16} className="app-muted" />
        <span className="text-sm app-muted">Terminal</span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 font-mono text-sm">
        {history.map((line, index) => (
          <div key={`${line}-${index}`} className="whitespace-pre-wrap">
            {line}
          </div>
        ))}
      </div>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          runCommand(command);
          setCommand("");
        }}
        className="h-9 border-t app-border flex items-center px-3 shrink-0"
      >
        <span className="text-green-400 mr-2">$</span>

        <input
          value={command}
          onChange={(event) => setCommand(event.target.value)}
          className="flex-1 bg-transparent outline-none text-sm font-mono"
          placeholder="type command..."
        />
      </form>
    </div>
  );
}
